@extends('layouts.main')

<link rel="stylesheet" href="/css/style_login.css">

@section('content')
        
            <div class="table table-bordered">
                <div class="">
                        <div class="table-header">
                            <div class="text">Login</div>
                        </div>
                </div>
                <div class="BodyTable_1">
                    <div>
                        <div>
                            <label for="" class="EmailnPass">E-Mail Address</label>
                            <input type="email" class="" id="">
                        </div>
                    </div>
                    <div>
                        <div>
                            <label for="">Password</label>
                            <input type="password" class="EmailnPass">
                        </div>
                    </div>
                </div>
                <div class="BodyTable_2">
                    <div>
                        <div class="">
                            <input class="" type="checkbox">
                            <label class="">Remember Me</label>
                        </div>
                    </div>
                    <div>
                        <button class="btn btn-primary" type="submit">Login</button>
                        <label for=""> <a href="#">Forgot Your Password?</a> </label>
                    </div>
                </div>
            </div>
        
    
@endsection