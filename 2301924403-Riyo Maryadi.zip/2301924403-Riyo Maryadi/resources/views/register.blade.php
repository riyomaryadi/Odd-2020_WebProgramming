@extends('layouts.main')

@section('content')
    <div class="table table-bordered">
        <div class="table-header">
            <div>
                <div class="">Register</div>
            </div>
        </div>
        <div class="BodyTable_2">
            <div>
                <div>
                    <label for="">Name</label>
                    <input type="text" class="" id="" maxlength="30">
                </div>
            </div>
            <div>
                <div>
                    <form>
                        <label for="">E-Mail Address</label>
                    <input type="email" required class="">
                    </form>
                </div>
            </div>
            <div>
                <div>
                    <form>
                        <label for="">Password</label>
                        <input type="password" class="" minlength="8">
                    </form>
                </div>
            </div>
            <div>
                <div>
                    <label for="">Confirm Password</label>
                    <input type="password" class="">
                </div>
            </div>
            <div class="">
                <label for="" class="">Gender</label>
                <select class="" id="" required>
                  <option selected disabled value="Male">Male</option>
                  <option>Male</option>
                  <option>Female</option>
                </select>
            </div>
        </div>
        
        <div class="d-grid gap-2 col-1 mx-auto">
            <button class="btn btn-primary" type="submit">Register</button>
        </div>
    </div>
@endsection