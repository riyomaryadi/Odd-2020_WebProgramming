

<?php $__env->startSection('content'); ?>
    <div class="table table-bordered">
        <div class="table-header">
            <div>
                <div class="">Register</div>
            </div>
        </div>
        <div class="BodyTable_2">
            <div>
                <div>
                    <label for="">Name</label>
                    <input type="text" class="" id="" maxlength="30">
                </div>
            </div>
            <div>
                <div>
                    <form>
                        <label for="">E-Mail Address</label>
                    <input type="email" required class="">
                    </form>
                </div>
            </div>
            $name = $confirm = "";
            <div>
                <div>
                    <form>
                        <label for="">Password</label>
                        <input type="password" class="" minlength="8">
                    </form>
                </div>
            </div>
            <div>
                <div>
                    <label for="">Confirm Password</label>
                    <input type="password" class="">
                </div>
            </div>
            <div class="">
                <label for="" class="">Gender</label>
                <select class="" id="" required>
                  <option selected disabled value="Male">Male</option>
                  <option>Male</option>
                  <option>Female</option>
                </select>
            </div>
        </div>
        
        <div class="d-grid gap-2 col-1 mx-auto">
            <button class="btn btn-primary" type="submit">Register</button>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Tugas Kuliah\Semester 5\Web Programming[COMP6681001]\BI01\Project\project\resources\views/register.blade.php ENDPATH**/ ?>